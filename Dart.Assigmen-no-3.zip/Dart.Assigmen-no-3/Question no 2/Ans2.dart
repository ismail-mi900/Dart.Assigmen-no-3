void main() {
  int ticket_price = 600;
  int five_movies = ticket_price * 5;
  print("Cost of One movie is $ticket_price");
  print("Cost of 5 movie is $five_movies");
}
